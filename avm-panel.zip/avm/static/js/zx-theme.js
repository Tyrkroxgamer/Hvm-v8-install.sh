/* Theme / colour picker: sets CSS variables --z1 --z2 --z3 --zl --zd (+ -rgb) and remembers the choice. */
(function () {
  var KEY = 'zxTheme';
  var PRESETS = [
    { id: 'blue',    name: 'Sky Blue', z1: '#0ea5e9', z2: '#38bdf8', z3: '#93c5fd' },
    { id: 'cyan',    name: 'Cyber Cyan', z1: '#06b6d4', z2: '#67e8f9', z3: '#38bdf8' },
    { id: 'violet',  name: 'Ultra Violet', z1: '#8b5cf6', z2: '#c084fc', z3: '#6366f1' },
    { id: 'magenta', name: 'Magenta', z1: '#d946ef', z2: '#f472b6', z3: '#a78bfa' },
    { id: 'rose',    name: 'Crimson', z1: '#f43f5e', z2: '#fb7185', z3: '#f97316' },
    { id: 'amber',   name: 'Solar', z1: '#f59e0b', z2: '#fbbf24', z3: '#fb923c' },
    { id: 'emerald', name: 'Matrix', z1: '#10b981', z2: '#34d399', z3: '#2dd4bf' },
    { id: 'neon',    name: 'Neon Blue', z1: '#2b7fff', z2: '#22d3ee', z3: '#818cf8' }
  ];

  function hexToRgb(h) { h = h.replace('#', ''); if (h.length === 3) h = h.replace(/(.)/g, '$1$1'); var n = parseInt(h, 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
  function rgbToHex(r, g, b) { return '#' + [r, g, b].map(function (v) { return ('0' + Math.round(v).toString(16)).slice(-2); }).join(''); }
  function rgbToHsl(r, g, b) {
    r /= 255; g /= 255; b /= 255; var mx = Math.max(r, g, b), mn = Math.min(r, g, b), h = 0, s = 0, l = (mx + mn) / 2;
    if (mx !== mn) { var d = mx - mn; s = l > .5 ? d / (2 - mx - mn) : d / (mx + mn);
      h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h /= 6; }
    return [h * 360, s, l];
  }
  function hslToHex(h, s, l) {
    h = ((h % 360) + 360) % 360 / 360;
    function f(p, q, t) { if (t < 0) t += 1; if (t > 1) t -= 1; if (t < 1 / 6) return p + (q - p) * 6 * t; if (t < .5) return q; if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6; return p; }
    var q = l < .5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
    return rgbToHex(f(p, q, h + 1 / 3) * 255, f(p, q, h) * 255, f(p, q, h - 1 / 3) * 255);
  }
  function tint(hex, dl) { var c = rgbToHsl.apply(null, hexToRgb(hex)); return hslToHex(c[0], c[1], Math.max(0.12, Math.min(0.88, c[2] + dl))); }
  function fromCustom(hex) {
    var c = rgbToHsl.apply(null, hexToRgb(hex)), s = Math.max(0.55, c[1]);
    return { z1: hex, z2: hslToHex(c[0] + 32, s, 0.58), z3: hslToHex(c[0] - 38, s, 0.66) };
  }
  function rgbStr(hex) { return hexToRgb(hex).join(','); }

  function apply(t) {
    var r = document.documentElement.style;
    r.setProperty('--z1', t.z1); r.setProperty('--z2', t.z2); r.setProperty('--z3', t.z3);
    var zl = tint(t.z1, 0.22), zd = tint(t.z1, -0.14);
    r.setProperty('--zl', zl); r.setProperty('--zd', zd);
    r.setProperty('--z1-rgb', rgbStr(t.z1)); r.setProperty('--z2-rgb', rgbStr(t.z2)); r.setProperty('--z3-rgb', rgbStr(t.z3)); r.setProperty('--zl-rgb', rgbStr(zl));
    var m = document.querySelector('meta[name="theme-color"]'); if (m) m.setAttribute('content', '#030914');
    try { window.dispatchEvent(new CustomEvent('zx-theme', { detail: t })); } catch (e) {}
  }
  function load() { try { return JSON.parse(localStorage.getItem(KEY)); } catch (e) { return null; } }
  function save(o) { try { localStorage.setItem(KEY, JSON.stringify(o)); } catch (e) {} }
  function resolve(o) {
    if (!o) return PRESETS[0];
    if (o.custom) return fromCustom(o.custom);
    for (var i = 0; i < PRESETS.length; i++) if (PRESETS[i].id === o.id) return PRESETS[i];
    return PRESETS[0];
  }

  var cur = load();
  apply(resolve(cur));          // apply immediately (no flash)

  function build() {
    if (document.getElementById('zxPick')) return;
    var css = document.createElement('style');
    css.textContent =
      '#zxPick{position:fixed;right:14px;bottom:calc(16px + env(safe-area-inset-bottom,0px));z-index:5000;font-family:inherit}' +
      '#zxBtn{width:48px;height:48px;border-radius:50%;border:1px solid rgba(var(--z2-rgb),.6);cursor:pointer;display:grid;place-items:center;color:#fff;' +
      'background:linear-gradient(135deg,var(--z1),var(--z2));box-shadow:0 0 22px rgba(var(--z1-rgb),.55);transition:transform .2s}' +
      '#zxBtn:active{transform:scale(.92)}#zxBtn svg{width:22px;height:22px}' +
      '#zxPanel{position:absolute;right:0;bottom:60px;width:min(280px,calc(100vw - 28px));padding:14px;border-radius:16px;display:none;' +
      'background:rgba(4,8,18,.94);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);border:1px solid rgba(var(--z2-rgb),.4);box-shadow:0 12px 40px rgba(0,0,0,.6),0 0 30px rgba(var(--z1-rgb),.25)}' +
      '#zxPick.open #zxPanel{display:block}' +
      '#zxPanel h4{margin:0 0 10px;font-size:.72rem;letter-spacing:.2em;text-transform:uppercase;color:var(--zl)}' +
      '.zxG{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}' +
      '.zxS{aspect-ratio:1;border-radius:12px;border:2px solid transparent;cursor:pointer;padding:0;position:relative}' +
      '.zxS.on{border-color:#fff;box-shadow:0 0 14px rgba(255,255,255,.5)}' +
      '.zxN{margin-top:8px;font-size:.78rem;color:#9db0cc;min-height:1.1em}' +
      '.zxC{display:flex;align-items:center;gap:10px;margin-top:12px;padding-top:12px;border-top:1px solid rgba(var(--z1-rgb),.25);font-size:.78rem;color:#9db0cc}' +
      '.zxC input{width:42px;height:32px;border:0;background:none;padding:0;cursor:pointer}' +
      '.zxR{margin-left:auto;background:none;border:1px solid rgba(var(--z2-rgb),.45);color:var(--zl);border-radius:8px;padding:5px 10px;font-size:.72rem;cursor:pointer}';
    document.head.appendChild(css);

    var w = document.createElement('div'); w.id = 'zxPick';
    var sw = PRESETS.map(function (p) {
      return '<button type="button" class="zxS" data-id="' + p.id + '" title="' + p.name + '" aria-label="' + p.name + '" style="background:linear-gradient(135deg,' + p.z1 + ',' + p.z2 + ' 60%,' + p.z3 + ')"></button>';
    }).join('');
    w.innerHTML =
      '<button type="button" id="zxBtn" aria-label="Change colours"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
      '<path d="M12 3a9 9 0 1 0 0 18c1.1 0 1.8-.9 1.5-1.9-.3-1 .3-2.1 1.4-2.1H17a4 4 0 0 0 4-4c0-5-4-10-9-10z"/><circle cx="7.5" cy="11" r="1"/><circle cx="10" cy="7" r="1"/><circle cx="15" cy="7.5" r="1"/></svg></button>' +
      '<div id="zxPanel"><h4>Theme colour</h4><div class="zxG">' + sw + '</div><div class="zxN" id="zxName"></div>' +
      '<div class="zxC"><span>Custom</span><input type="color" id="zxCustom" value="#0ea5e9" aria-label="Custom colour"><button type="button" class="zxR" id="zxReset">Reset</button></div></div>';
    document.body.appendChild(w);

    var name = w.querySelector('#zxName'), cust = w.querySelector('#zxCustom');
    function mark() {
      var o = load();
      [].forEach.call(w.querySelectorAll('.zxS'), function (b) { b.classList.toggle('on', !!o && !o.custom && b.getAttribute('data-id') === o.id || (!o && b.getAttribute('data-id') === 'blue')); });
      if (o && o.custom) { name.textContent = 'Custom'; cust.value = o.custom; }
      else { var t = resolve(o); name.textContent = t.name; cust.value = t.z1; }
    }
    w.querySelector('#zxBtn').addEventListener('click', function (e) { e.stopPropagation(); w.classList.toggle('open'); });
    document.addEventListener('click', function (e) { if (!w.contains(e.target)) w.classList.remove('open'); });
    [].forEach.call(w.querySelectorAll('.zxS'), function (b) {
      b.addEventListener('click', function () { var o = { id: b.getAttribute('data-id') }; save(o); apply(resolve(o)); mark(); });
    });
    cust.addEventListener('input', function () { var o = { custom: cust.value }; save(o); apply(resolve(o)); mark(); });
    w.querySelector('#zxReset').addEventListener('click', function () { try { localStorage.removeItem(KEY); } catch (e) {} apply(PRESETS[0]); mark(); });
    mark();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', build); else build();
})();
