/* avm-fx.js - extra motion for the sky-blue theme (all optional, safe to remove) */
(function () {
  'use strict';
  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var FILLS = '.progress > .progress-bar, .progress-bar-premium > .progress-fill, .progress-bar > .progress-fill';
  var CARDS = '.card, .stat-card, .premium-stat-card, .action-card, .node-card';
  var TILT  = '.stat-card, .premium-stat-card, .action-card, .node-card';

  function ready(fn) { if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn); else fn(); }

  ready(function () {
    /* 1. slow aurora behind everything */
    if (!reduce && !document.getElementById('avmAurora')) {
      var a = document.createElement('div'); a.id = 'avmAurora'; a.setAttribute('aria-hidden', 'true'); document.body.appendChild(a);
    }

    /* 2. progress bars fill up from 0 on first paint (staggered) */
    if (!reduce) {
      [].forEach.call(document.querySelectorAll(FILLS), function (el, i) {
        var w = el.style.width;
        if (!w || w === '0%' || w === '0px') return;
        el.style.transition = 'none'; el.style.width = '0%';
        void el.offsetWidth;
        setTimeout(function () { el.style.transition = ''; el.style.width = w; }, 120 + Math.min(i, 12) * 70);
      });
    }

    /* 3. red edge-glow while any bar is in the danger zone */
    var t = 0;
    function checkDanger() {
      var hit = document.querySelector('.progress > .progress-bar.danger, .progress-bar-premium > .progress-fill.danger');
      document.body.classList.toggle('avm-has-danger', !!hit);
    }
    function schedule() { clearTimeout(t); t = setTimeout(checkDanger, 400); }
    checkDanger();
    if ('MutationObserver' in window) {
      new MutationObserver(schedule).observe(document.body, { subtree: true, attributes: true, attributeFilter: ['class'] });
    }
  });

  /* 4. mouse glow + soft 3D tilt on cards (desktop only) */
  if (!reduce && window.matchMedia && matchMedia('(hover: hover) and (pointer: fine)').matches) {
    var last = null, raf = 0, ev = null;
    function reset(el) { if (!el) return; el.style.removeProperty('--rx'); el.style.removeProperty('--ry'); }
    function frame() {
      raf = 0; if (!ev) return;
      var el = ev.target && ev.target.closest ? ev.target.closest(CARDS) : null;
      if (last && last !== el) reset(last);
      last = el; if (!el) return;
      var r = el.getBoundingClientRect(), x = ev.clientX - r.left, y = ev.clientY - r.top;
      el.style.setProperty('--mx', x + 'px'); el.style.setProperty('--my', y + 'px');
      if (el.matches(TILT) && r.width < 520) {
        el.style.setProperty('--ry', ((x / r.width - 0.5) * 7).toFixed(2) + 'deg');
        el.style.setProperty('--rx', ((y / r.height - 0.5) * -7).toFixed(2) + 'deg');
      }
    }
    document.addEventListener('mousemove', function (e) { ev = e; if (!raf) raf = requestAnimationFrame(frame); }, { passive: true });
    document.addEventListener('mouseleave', function () { reset(last); last = null; });
  }

  /* 5. bell rings when the unread badge shows up */
  ready(function () {
    var b = document.getElementById('notificationBadge');
    if (!b || reduce || !('MutationObserver' in window)) return;
    new MutationObserver(function () {
      if (b.style.display !== 'none') {
        var i = b.parentElement && b.parentElement.querySelector('i'); if (!i) return;
        i.style.animation = 'none'; void i.offsetWidth; i.style.animation = 'avm2Bell .9s ease'; i.style.transformOrigin = '50% 0';
      }
    }).observe(b, { attributes: true, attributeFilter: ['style'] });
  });
})();
