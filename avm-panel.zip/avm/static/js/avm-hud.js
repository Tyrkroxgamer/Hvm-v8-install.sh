/* avm-hud.js - HUD UI layer: Ctrl+K palette, mini sidebar, Lite mode, gauges, count-up.
   Everything is optional / additive. Preferences live in localStorage (try/catch safe). */
(function () {
  'use strict';
  var doc = document, root = doc.documentElement;
  function $(s, c) { return (c || doc).querySelector(s); }
  function $$(s, c) { return [].slice.call((c || doc).querySelectorAll(s)); }
  function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) {} return null; }
  function ready(fn) { if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', fn); else fn(); }
  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- Lite mode + mini sidebar (state is applied early by an inline script in <head>) ---------- */
  function isLite() { return root.classList.contains('hud-lite'); }
  function setLite(on) {
    root.classList.toggle('hud-lite', on); store('hudLite', on ? '1' : '0');
    var v = $('#bgVideo'); if (v) { if (on) v.pause(); else { var p = v.play(); if (p && p.catch) p.catch(function () {}); } }
    var b = $('#hudLiteBtn'); if (b) b.classList.toggle('on', on);
    toast(on ? 'Lite mode ON - heavy effects off' : 'Lite mode OFF - full HUD');
  }
  function setMini(on) { root.classList.toggle('hud-mini', on); store('hudMini', on ? '1' : '0'); }

  var toastEl, toastT;
  function toast(msg) {
    if (!toastEl) { toastEl = doc.createElement('div'); toastEl.style.cssText = 'position:fixed;left:50%;bottom:84px;transform:translateX(-50%);z-index:6000;padding:.55rem 1rem;background:rgba(4,12,28,.95);border:1px solid var(--z2);color:var(--zl);font:600 .78rem "Space Grotesk",sans-serif;letter-spacing:.06em;box-shadow:0 0 22px rgba(var(--z2-rgb),.4);transition:opacity .25s;pointer-events:none'; doc.body.appendChild(toastEl); }
    toastEl.textContent = msg; toastEl.style.opacity = 1; clearTimeout(toastT); toastT = setTimeout(function () { toastEl.style.opacity = 0; }, 1800);
  }

  /* ---------- circular gauge helper ---------- */
  var R = 32, C = 2 * Math.PI * R;
  function ringHTML(label, cls) {
    return '<div class="hud-ring ' + (cls || '') + '"><svg viewBox="0 0 80 80"><circle class="trk" cx="40" cy="40" r="' + R + '"/><circle class="val" cx="40" cy="40" r="' + R + '"/></svg><div class="num">0%</div><div class="lbl">' + label + '</div></div>';
  }
  function setRing(el, pct, text, level) {
    pct = Math.max(0, Math.min(100, +pct || 0));
    var v = $('.val', el); if (v) v.style.strokeDasharray = (C * pct / 100).toFixed(1) + ' ' + C.toFixed(1);
    var n = $('.num', el); if (n) n.textContent = text != null ? text : Math.round(pct) + '%';
    if (level) { el.classList.remove('warn', 'danger'); if (level !== 'ok') el.classList.add(level); }
  }
  function levelOf(p) { return p > 80 ? 'danger' : p > 60 ? 'warn' : 'ok'; }

  /* ---------- VPS cards: replace the 3 bars with 3 live rings (old bars stay hidden, live-stats.js keeps updating them) ---------- */
  function initCardRings() {
    $$('.performance-section').forEach(function (sec) {
      if (sec.classList.contains('hud-done')) return;
      var rows = $$('.metric-row', sec); if (rows.length < 3) return;
      var wrap = doc.createElement('div'); wrap.className = 'hud-rings';
      wrap.innerHTML = ringHTML('CPU') + ringHTML('RAM') + ringHTML('Disk');
      sec.appendChild(wrap); sec.classList.add('hud-done');
      var rings = $$('.hud-ring', wrap);
      function sync() {
        rows.slice(0, 3).forEach(function (row, i) {
          var fill = $('.progress-fill, .progress-bar', row), txt = $('.metric-value', row);
          var p = parseFloat((fill && fill.style.width) || (txt && txt.textContent)) || 0;
          setRing(rings[i], p, null, levelOf(p));
        });
      }
      requestAnimationFrame(function () { setTimeout(sync, 150); });
      /* watch only the original rows (NOT the rings, or we would trigger ourselves in a loop) */
      if ('MutationObserver' in window) { var mo = new MutationObserver(sync); rows.forEach(function (r) { mo.observe(r, { subtree: true, attributes: true, characterData: true, childList: true }); }); }
    });
  }

  /* ---------- dashboard hero strip (fleet status rings) + count-up numbers ---------- */
  function initDashboardStrip() {
    var grid = $('.stats-grid'), data = $('#hudFleet');
    if (!grid || !data) return;
    var total = +data.dataset.total || 0, run = +data.dataset.running || 0, stop = +data.dataset.stopped || 0, sus = +data.dataset.suspended || 0;
    var pct = function (n) { return total ? n * 100 / total : 0; };
    var strip = doc.createElement('div'); strip.className = 'hud-strip';
    strip.innerHTML = ringHTML('Online', 'ok') + ringHTML('Stopped', stop ? 'warn' : '') + ringHTML('Suspended', sus ? 'danger' : '') + ringHTML('Fleet');
    grid.parentNode.insertBefore(strip, grid);
    var rs = $$('.hud-ring', strip);
    [[rs[0], pct(run), run + '/' + total], [rs[1], pct(stop), String(stop)], [rs[2], pct(sus), String(sus)], [rs[3], 100, String(total)]].forEach(function (a, i) {
      var sub = doc.createElement('div'); sub.className = 'sub'; sub.textContent = ['running now', 'powered off', 'needs attention', 'total VPS'][i]; a[0].appendChild(sub);
      setTimeout(function () { setRing(a[0], a[1], a[2]); }, 200 + i * 120);
    });
    if (rs[0] && total && run === 0) rs[0].classList.add('danger'); else if (rs[0]) rs[0].classList.add('ok');
  }
  function countUp() {
    if (reduce || isLite()) return;
    $$('.stat-value').forEach(function (el) {
      var node = el.firstChild; if (!node || node.nodeType !== 3) return;
      var end = parseFloat(node.nodeValue); if (!isFinite(end) || end <= 0 || end > 99999) return;
      var t0 = null, dec = (node.nodeValue.split('.')[1] || '').length;
      function step(t) { if (!t0) t0 = t; var k = Math.min(1, (t - t0) / 900), e = 1 - Math.pow(1 - k, 3); node.nodeValue = (end * e).toFixed(dec); if (k < 1) requestAnimationFrame(step); else node.nodeValue = end.toFixed(dec); }
      requestAnimationFrame(step);
    });
  }

  /* ---------- decorations ---------- */
  var TICK_SEL = '.vps-card, .premium-stat-card, .chart-card, .vps-table-card, .toolbar-card, .action-card, .hero-welcome, .lg-card, .node-card';
  function addTicks() {
    $$(TICK_SEL).forEach(function (el) {
      if (el.querySelector(':scope > .hud-ticks')) return;
      var s = doc.createElement('span'); s.className = 'hud-ticks'; s.setAttribute('aria-hidden', 'true'); el.appendChild(s);
    });
  }
  function addOverlays() {
    if (!$('#hudGrid')) { var g = doc.createElement('div'); g.id = 'hudGrid'; g.setAttribute('aria-hidden', 'true'); doc.body.appendChild(g); }
    if (!$('#hudScan')) { var s = doc.createElement('div'); s.id = 'hudScan'; s.setAttribute('aria-hidden', 'true'); doc.body.appendChild(s); }
  }
  function tooltipsForMini() { $$('.sidebar .nav-item').forEach(function (a) { var s = $('span', a); if (s && !a.title) a.title = s.textContent.trim(); }); }

  /* remember VPS list so the palette can jump to any VPS from any page */
  function rememberVps() {
    var cards = $$('.vps-card[data-id]'); if (!cards.length) return;
    var list = cards.map(function (c) {
      var n = $('.vps-info h3 span', c);
      var a = $('a[href*="/vps/"]', c);
      return { id: c.dataset.id, name: (n ? n.textContent : c.dataset.name || '').trim(), ip: c.dataset.ip || '', st: c.dataset.status || '', href: a ? a.getAttribute('href') : null };
    });
    store('hudVps', JSON.stringify(list));
  }

  /* ---------- Ctrl+K command palette ---------- */
  var pal, palIn, palList, items = [], shown = [], sel = 0;
  function buildItems() {
    var out = [], seen = {};
    $$('.sidebar .nav-item, .sidebar .nav-admin-switch, .sidebar .nav-back-btn').forEach(function (a) {
      var label = a.textContent.replace(/\s+/g, ' ').trim().replace(/\d+$/, '').trim(), href = a.getAttribute('href'); if (!label || !href || seen[href]) return; seen[href] = 1;
      var ic = $('i', a); out.push({ g: 'Go to', t: label, i: ic ? ic.className : 'fas fa-arrow-right', href: href });
    });
    var vl = []; try { vl = JSON.parse(store('hudVps') || '[]'); } catch (e) {}
    vl.forEach(function (v) {
      var h = v.href || ('/vps/' + v.id); var dot = v.st === 'running' ? 'LIVE' : v.st === 'suspended' ? 'SUSPENDED' : 'OFF';
      out.push({ g: 'My VPS', t: v.name || ('VPS #' + v.id), i: 'fas fa-server', href: h, sub: (v.ip ? v.ip + ' · ' : '') + dot, key: (v.name + ' ' + v.ip + ' ' + v.id) });
    });
    out.push({ g: 'Actions', t: isLite() ? 'Turn Lite mode OFF (full effects)' : 'Turn Lite mode ON (faster on mobile)', i: 'fas fa-bolt', fn: function () { setLite(!isLite()); } });
    out.push({ g: 'Actions', t: 'Toggle icon-only sidebar', i: 'fas fa-table-columns', fn: function () { setMini(!root.classList.contains('hud-mini')); } });
    var lo = $('.user-dropdown a[href*="logout"]'); if (lo) out.push({ g: 'Actions', t: 'Logout', i: 'fas fa-sign-out-alt', href: lo.getAttribute('href') });
    return out;
  }
  function score(q, s) {
    s = s.toLowerCase(); if (!q) return 1; var i = s.indexOf(q); if (i >= 0) return 100 - i;
    var j = 0, sc = 0; for (var k = 0; k < s.length && j < q.length; k++) if (s[k] === q[j]) { j++; sc += 2; } return j === q.length ? sc : 0;
  }
  function render() {
    var q = palIn.value.trim().toLowerCase();
    shown = items.map(function (it) { return { it: it, s: score(q, (it.key || it.t) + ' ' + it.t + ' ' + (it.sub || '')) }; }).filter(function (x) { return x.s > 0; })
      .sort(function (a, b) { return q ? b.s - a.s : 0; }).slice(0, 40).map(function (x) { return x.it; });
    sel = Math.min(sel, Math.max(0, shown.length - 1));
    var html = '', last = '';
    shown.forEach(function (it, n) {
      if (it.g !== last) { html += '<div class="grp">' + it.g + '</div>'; last = it.g; }
      html += '<div class="it' + (n === sel ? ' sel' : '') + '" data-n="' + n + '"><i class="' + esc(it.i) + '"></i><span>' + esc(it.t) + '</span>' + (it.sub ? '<small>' + esc(it.sub) + '</small>' : '') + '</div>';
    });
    palList.innerHTML = html || '<div class="empty">Kuch nahi mila</div>';
    var s = $('.it.sel', palList); if (s && s.scrollIntoView) s.scrollIntoView({ block: 'nearest' });
  }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function run(it) { closePal(); if (!it) return; if (it.fn) it.fn(); else if (it.href) location.href = it.href; }
  function openPal() {
    if (!pal) {
      pal = doc.createElement('div'); pal.id = 'hudPalette';
      pal.innerHTML = '<div class="box" role="dialog" aria-label="Command palette"><div class="in"><i class="fas fa-terminal"></i><input type="text" placeholder="Page ya VPS dhoondo...  (naam, IP, ID)" autocomplete="off" spellcheck="false"></div><div class="list"></div><div class="foot"><span><kbd>↑</kbd> <kbd>↓</kbd> move</span><span><kbd>Enter</kbd> open</span><span><kbd>Esc</kbd> close</span></div></div>';
      doc.body.appendChild(pal); palIn = $('input', pal); palList = $('.list', pal);
      pal.addEventListener('mousedown', function (e) { if (e.target === pal) closePal(); });
      palList.addEventListener('mousemove', function (e) { var r = e.target.closest('.it'); if (r && +r.dataset.n !== sel) { sel = +r.dataset.n; $$('.it', palList).forEach(function (x) { x.classList.toggle('sel', x === r); }); } });
      palList.addEventListener('click', function (e) { var r = e.target.closest('.it'); if (r) run(shown[+r.dataset.n]); });
      palIn.addEventListener('input', function () { sel = 0; render(); });
      palIn.addEventListener('keydown', function (e) {
        if (e.key === 'ArrowDown') { sel = Math.min(shown.length - 1, sel + 1); render(); e.preventDefault(); }
        else if (e.key === 'ArrowUp') { sel = Math.max(0, sel - 1); render(); e.preventDefault(); }
        else if (e.key === 'Enter') { run(shown[sel]); e.preventDefault(); }
      });
    }
    items = buildItems(); palIn.value = ''; sel = 0; render(); pal.classList.add('open'); setTimeout(function () { palIn.focus(); }, 20);
  }
  function closePal() { if (pal) pal.classList.remove('open'); }
  window.avmPalette = { open: openPal, close: closePal };

  function typing(e) { var t = e.target; return t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable); }
  doc.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); pal && pal.classList.contains('open') ? closePal() : openPal(); }
    else if (e.key === 'Escape') closePal();
    else if (e.key === '/' && !typing(e) && !e.ctrlKey && !e.metaKey) { e.preventDefault(); openPal(); }
  });

  /* ---------- boot ---------- */
  ready(function () {
    addOverlays(); addTicks(); initCardRings(); initDashboardStrip(); countUp(); tooltipsForMini(); rememberVps();
    var lb = $('#hudLiteBtn'); if (lb) { lb.classList.toggle('on', isLite()); lb.addEventListener('click', function () { setLite(!isLite()); }); }
    var mb = $('#hudMiniBtn'); if (mb) mb.addEventListener('click', function () { setMini(!root.classList.contains('hud-mini')); });
    var pb = $('#hudPalBtn'); if (pb) pb.addEventListener('click', openPal);
    var bm = $('#hudBarMenu'); if (bm) bm.addEventListener('click', function () { var t = $('#menuToggle'); if (t) t.click(); });
    var bp = $('#hudBarSearch'); if (bp) bp.addEventListener('click', openPal);
    /* pages that add cards later (filters, live refresh) */
    if ('MutationObserver' in window) {
      var t = 0; new MutationObserver(function () { clearTimeout(t); t = setTimeout(function () { addTicks(); initCardRings(); }, 250); })
        .observe($('.content') || doc.body, { childList: true, subtree: true });
    }
  });
})();
