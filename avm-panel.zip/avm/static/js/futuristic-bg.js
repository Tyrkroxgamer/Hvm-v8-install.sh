(function () {
  var c = document.getElementById('fxBg');
  if (!c) return;
  var ctx = c.getContext('2d');
  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var W = 0, H = 0, dpr = Math.min(window.devicePixelRatio || 1, 1.5), P = [], t = 0, raf = 0;

  function resize() {
    W = window.innerWidth; H = window.innerHeight;
    c.width = W * dpr; c.height = H * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    var n = Math.max(28, Math.min(70, Math.floor(W * H / 14000)));
    P = [];
    for (var i = 0; i < n; i++) P.push({
      x: Math.random() * W, y: Math.random() * H,
      vx: (Math.random() - 0.5) * 0.25, vy: -0.1 - Math.random() * 0.3,
      r: 0.6 + Math.random() * 1.6, ph: Math.random() * 6.28
    });
  }

  function draw() {
    t += 0.016;
    var g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, '#02040a'); g.addColorStop(0.55, '#040916'); g.addColorStop(1, '#030610');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);

    // soft blue glows
    var r1 = ctx.createRadialGradient(W * 0.2, H * 0.12, 0, W * 0.2, H * 0.12, Math.max(W, H) * 0.55);
    r1.addColorStop(0, 'rgba(43,127,255,0.20)'); r1.addColorStop(1, 'rgba(43,127,255,0)');
    ctx.fillStyle = r1; ctx.fillRect(0, 0, W, H);
    var r2 = ctx.createRadialGradient(W * 0.9, H * 0.7, 0, W * 0.9, H * 0.7, Math.max(W, H) * 0.5);
    r2.addColorStop(0, 'rgba(99,102,241,0.16)'); r2.addColorStop(1, 'rgba(99,102,241,0)');
    ctx.fillStyle = r2; ctx.fillRect(0, 0, W, H);

    // perspective grid floor
    var hz = H * 0.62, vx = W / 2;
    ctx.lineWidth = 1;
    for (var i = -14; i <= 14; i++) {
      var a = 0.05 + 0.10 * (1 - Math.abs(i) / 15);
      ctx.strokeStyle = 'rgba(56,160,255,' + a + ')';
      ctx.beginPath(); ctx.moveTo(vx + i * 8, hz); ctx.lineTo(vx + i * W * 0.22, H); ctx.stroke();
    }
    var off = (t * 0.35) % 1;
    for (var k = 0; k < 14; k++) {
      var p = (k + off) / 14, y = hz + (H - hz) * p * p;
      ctx.strokeStyle = 'rgba(56,189,248,' + (0.03 + 0.16 * p) + ')';
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
    }
    var hg = ctx.createLinearGradient(0, hz - 2, 0, hz + 60);
    hg.addColorStop(0, 'rgba(34,211,238,0.30)'); hg.addColorStop(1, 'rgba(34,211,238,0)');
    ctx.fillStyle = hg; ctx.fillRect(0, hz - 2, W, 60);

    // particles + links
    for (var i2 = 0; i2 < P.length; i2++) {
      var q = P[i2];
      if (!reduce) { q.x += q.vx; q.y += q.vy; }
      if (q.y < -5) { q.y = H + 5; q.x = Math.random() * W; }
      if (q.x < -5) q.x = W + 5; if (q.x > W + 5) q.x = -5;
      var tw = 0.5 + 0.5 * Math.sin(t * 1.6 + q.ph);
      ctx.fillStyle = 'rgba(140,210,255,' + (0.25 + 0.6 * tw) + ')';
      ctx.beginPath(); ctx.arc(q.x, q.y, q.r, 0, 6.283); ctx.fill();
      for (var j = i2 + 1; j < P.length; j++) {
        var dx = q.x - P[j].x, dy = q.y - P[j].y, d = dx * dx + dy * dy;
        if (d < 12000) {
          ctx.strokeStyle = 'rgba(56,160,255,' + (0.16 * (1 - d / 12000)) + ')';
          ctx.beginPath(); ctx.moveTo(q.x, q.y); ctx.lineTo(P[j].x, P[j].y); ctx.stroke();
        }
      }
    }
    if (!reduce) raf = requestAnimationFrame(draw);
  }

  resize();
  window.addEventListener('resize', function () { resize(); if (reduce) draw(); });
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) cancelAnimationFrame(raf);
    else if (!reduce) { cancelAnimationFrame(raf); raf = requestAnimationFrame(draw); }
  });
  draw();
})();
