#!/usr/bin/env python3
"""
avm-panel Discord Bot  -  deploy and manage VPS straight from Discord.
Powered by tyrkrox_tech

The bot is started/stopped from the panel (Admin -> Discord Bot) and reads all of its
settings (token, bot name, main admin, limits ...) from the panel database.
Actions (deploy / start / stop / restart / delete ...) go through the panel's own REST API,
so everything behaves exactly like it does in the web panel.
"""
import os
import re
import sys
import time
import random
import sqlite3
import secrets
import string
import asyncio
import logging
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE_DIR)

try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(BASE_DIR, '.env'))
except Exception:
    pass

try:
    import aiohttp
    import discord
    from discord import app_commands
except ImportError:
    print("discord.py is not installed. Run:  pip install -U discord.py   (inside the panel venv)")
    sys.exit(2)

logging.basicConfig(level=logging.INFO, format='%(asctime)s [bot] %(levelname)s %(message)s')
log = logging.getLogger('avm-bot')

DB_PATH = os.getenv('DATABASE_PATH') or ('hvm.db' if (os.path.exists('hvm.db') and not os.path.exists('avm.db')) else 'avm.db')
PORT = int(os.getenv('PORT', '5000'))
API_BASE = os.getenv('BOT_API_BASE', f'http://127.0.0.1:{PORT}/api/v1').rstrip('/')

COLOR_MAIN = 0x3B82F6
COLOR_OK = 0x10B981
COLOR_ERR = 0xEF4444
COLOR_WARN = 0xF59E0B

FALLBACK_OS = [
    ('Ubuntu 22.04 LTS', 'ubuntu:22.04'),
    ('Ubuntu 24.04 LTS', 'ubuntu:24.04'),
    ('Ubuntu 20.04 LTS', 'ubuntu:20.04'),
    ('Debian 12', 'images:debian/12'),
    ('Debian 11', 'images:debian/11'),
]
_os_cache = {'ts': 0, 'items': []}


# ----------------------------------------------------------------------------
# Database helpers (settings + read-only lookups)
# ----------------------------------------------------------------------------
def db():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA busy_timeout=30000')
    return conn


def get_setting(key, default=''):
    try:
        with db() as conn:
            row = conn.execute('SELECT value FROM settings WHERE key = ?', (key,)).fetchone()
            return row['value'] if row and row['value'] is not None else default
    except Exception as e:
        log.error('get_setting(%s) failed: %s', key, e)
        return default


def set_setting(key, value):
    with db() as conn:
        conn.execute('INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, ?)',
                     (key, value, datetime.now().isoformat()))
        conn.commit()


def query(sql, params=()):
    with db() as conn:
        return [dict(r) for r in conn.execute(sql, params).fetchall()]


def query_one(sql, params=()):
    rows = query(sql, params)
    return rows[0] if rows else None


def to_int(value, default):
    try:
        return int(str(value).strip())
    except Exception:
        return default


def footer_text():
    return get_setting('footer_text', 'Powered by tyrkrox_tech') or 'Powered by tyrkrox_tech'


def main_admin_id():
    return re.sub(r'\D', '', get_setting('bot_main_admin_id', ''))


def extra_admin_ids():
    raw = get_setting('bot_extra_admins', '')
    return {x for x in re.split(r'[\s,;]+', raw) if x.isdigit()}


def is_main_admin(discord_id):
    mid = main_admin_id()
    return bool(mid) and str(discord_id) == mid


def is_bot_admin(discord_id):
    return is_main_admin(discord_id) or str(discord_id) in extra_admin_ids()


def panel_user_by_discord(discord_id):
    return query_one('SELECT * FROM users WHERE discord_id = ?', (str(discord_id),))


def panel_user_by_name(username):
    return query_one('SELECT * FROM users WHERE lower(username) = lower(?)', (username.strip(),))


def vps_by_id(vps_id):
    return query_one('SELECT v.*, u.username AS owner_name FROM vps v '
                     'LEFT JOIN users u ON v.user_id = u.id WHERE v.id = ?', (vps_id,))


def vps_for_user(user_id):
    return query('SELECT * FROM vps WHERE user_id = ? ORDER BY id DESC', (user_id,))


def status_icon(vps):
    if vps.get('suspended'):
        return '⛔'
    return {'running': '🟢', 'stopped': '🔴', 'installing': '🛠️', 'migrating': '🚚'}.get(
        (vps.get('status') or '').lower(), '⚪')


# ----------------------------------------------------------------------------
# Panel REST API client
# ----------------------------------------------------------------------------
_session = None


async def api(method, path, payload=None, timeout=240):
    """Call the panel REST API with the bot's admin key. Returns (http_status, json_dict)."""
    global _session
    key = get_setting('bot_api_key', '')
    if not key:
        return 0, {'success': False, 'error': 'Bot API key missing. Open Admin -> Discord Bot and press Save.'}
    if _session is None or _session.closed:
        _session = aiohttp.ClientSession()
    try:
        async with _session.request(method, f'{API_BASE}{path}', json=payload,
                                    headers={'X-API-Key': key},
                                    timeout=aiohttp.ClientTimeout(total=timeout)) as resp:
            try:
                data = await resp.json(content_type=None)
            except Exception:
                data = {'success': False, 'error': f'HTTP {resp.status}'}
            return resp.status, data
    except asyncio.TimeoutError:
        return 0, {'success': False, 'error': 'The panel took too long to answer.'}
    except Exception as e:
        return 0, {'success': False, 'error': f'Cannot reach panel API: {e}'}


async def os_templates():
    if time.time() - _os_cache['ts'] < 300 and _os_cache['items']:
        return _os_cache['items']
    status, data = await api('GET', '/os-templates', timeout=20)
    items = []
    if status == 200 and data.get('success'):
        for t in data.get('templates', []):
            val = t.get('key') or t.get('image')
            if val:
                items.append((t.get('name') or val, val))
    if not items:
        items = list(FALLBACK_OS)
    _os_cache.update(ts=time.time(), items=items)
    return items


def err_text(data):
    return str((data or {}).get('error') or (data or {}).get('message') or 'Unknown error')[:500]


# ----------------------------------------------------------------------------
# Discord client
# ----------------------------------------------------------------------------
intents = discord.Intents.default()
client = discord.Client(intents=intents)
tree = app_commands.CommandTree(client)


def embed(title, description='', color=COLOR_MAIN):
    e = discord.Embed(title=title, description=description[:4000], color=color)
    e.set_footer(text=footer_text())
    return e


async def reply(interaction, **kwargs):
    """Send a response whether or not we've already deferred."""
    kwargs.setdefault('ephemeral', True)
    if interaction.response.is_done():
        return await interaction.followup.send(**kwargs)
    return await interaction.response.send_message(**kwargs)


def bot_admin_only():
    async def predicate(interaction: discord.Interaction):
        if is_bot_admin(interaction.user.id):
            return True
        raise app_commands.CheckFailure('This command is for bot admins only.')
    return app_commands.check(predicate)


def main_admin_only():
    async def predicate(interaction: discord.Interaction):
        if is_main_admin(interaction.user.id):
            return True
        raise app_commands.CheckFailure('Only the main admin can use this command.')
    return app_commands.check(predicate)


def require_panel_user(discord_id):
    """Return the linked panel account or None."""
    return panel_user_by_discord(discord_id)


NOT_LINKED = ('You do not have a panel account linked to this Discord account.\n'
              'Use `/register` to create one, or log in to the panel with Discord / ask an admin to `/link` you.')


def can_manage(discord_id, vps):
    if is_bot_admin(discord_id):
        return True
    user = panel_user_by_discord(discord_id)
    return bool(user and vps and vps['user_id'] == user['id'])


async def vps_autocomplete(interaction: discord.Interaction, current: str):
    try:
        if is_bot_admin(interaction.user.id):
            rows = query('SELECT id, container_name FROM vps ORDER BY id DESC LIMIT 200')
        else:
            user = panel_user_by_discord(interaction.user.id)
            rows = vps_for_user(user['id']) if user else []
        cur = (current or '').lower()
        out = []
        for r in rows:
            label = f"{r['container_name']} (#{r['id']})"
            if cur in label.lower():
                out.append(app_commands.Choice(name=label[:100], value=int(r['id'])))
            if len(out) >= 25:
                break
        return out
    except Exception:
        return []


async def os_autocomplete(interaction: discord.Interaction, current: str):
    items = await os_templates()
    cur = (current or '').lower()
    out = []
    for name, val in items:
        if cur in name.lower() or cur in val.lower():
            out.append(app_commands.Choice(name=name[:100], value=val[:100]))
        if len(out) >= 25:
            break
    return out


def vps_embed(vps, title=None):
    e = embed(title or f"{status_icon(vps)} {vps['container_name']}  (#{vps['id']})")
    e.add_field(name='Status', value=f"{status_icon(vps)} {vps.get('status') or 'unknown'}"
                                     + (' (suspended)' if vps.get('suspended') else ''), inline=True)
    e.add_field(name='OS', value=vps.get('os_version') or '-', inline=True)
    e.add_field(name='Resources', value=f"{vps.get('ram')} RAM / {vps.get('cpu')} CPU / {vps.get('storage')} disk", inline=False)
    e.add_field(name='IP', value=vps.get('ip_address') or 'assigned automatically', inline=True)
    if vps.get('owner_name'):
        e.add_field(name='Owner', value=vps['owner_name'], inline=True)
    if vps.get('expires_at'):
        e.add_field(name='Expires', value=str(vps['expires_at'])[:10], inline=True)
    return e


# ----------------------------------------------------------------------------
# Deploy helpers
# ----------------------------------------------------------------------------
def clean_name(name):
    name = re.sub(r'[^a-z0-9\-]', '', name.lower().replace(' ', '-').replace('_', '-'))
    return name.strip('-')


def pick_node():
    configured = get_setting('bot_default_node_id', '').strip()
    if configured.isdigit() and query_one('SELECT id FROM nodes WHERE id = ?', (int(configured),)):
        return int(configured)
    nodes = query('SELECT * FROM nodes')
    if not nodes:
        return None
    def free(n):
        return to_int(n.get('total_vps'), 0) - to_int(n.get('used_vps'), 0)
    nodes.sort(key=free, reverse=True)
    return nodes[0]['id']


async def start_deploy(interaction, owner, name, os_version, ram, cpu, storage, node_id=None, limited=True):
    """Validate and start a VPS deployment on behalf of panel user `owner`."""
    name = clean_name(name)
    if len(name) < 3 or len(name) > 30:
        return await reply(interaction, embed=embed('Invalid name', 'Use 3-30 letters, numbers or dashes.', COLOR_ERR))
    if ram < 1 or cpu < 1 or storage < 1:
        return await reply(interaction, embed=embed('Invalid size', 'RAM, CPU and storage must be at least 1.', COLOR_ERR))
    if limited:
        mr, mc, ms = (to_int(get_setting('bot_user_max_ram', '4'), 4),
                      to_int(get_setting('bot_user_max_cpu', '2'), 2),
                      to_int(get_setting('bot_user_max_storage', '20'), 20))
        if ram > mr or cpu > mc or storage > ms:
            return await reply(interaction, embed=embed(
                'Over the limit', f'Max for members: **{mr} GB RAM**, **{mc} CPU**, **{ms} GB disk**.', COLOR_ERR))
    if query_one('SELECT id FROM vps WHERE container_name = ?', (name,)):
        return await reply(interaction, embed=embed('Name taken', f'`{name}` already exists, choose another name.', COLOR_ERR))
    node_id = node_id or pick_node()
    if not node_id:
        return await reply(interaction, embed=embed('No node', 'No node is configured in the panel yet.', COLOR_ERR))

    status, data = await api('POST', '/vps', {
        'hostname': name, 'user_id': owner['id'], 'node_id': node_id,
        'cpu': cpu, 'ram': ram, 'storage': storage, 'os_version': os_version,
    })
    if status not in (200, 201) or not data.get('success'):
        return await reply(interaction, embed=embed('Deploy failed', err_text(data), COLOR_ERR))

    vps_id = data.get('vps_id')
    e = embed('🛠️ Deploying your VPS', f"**{data.get('container_name', name)}**  (#{vps_id})\n"
              f"{os_version}  |  {ram} GB RAM  |  {cpu} CPU  |  {storage} GB disk\n\n"
              "This takes a few minutes. I will DM you the login details when it is ready.", COLOR_WARN)
    await reply(interaction, embed=e)
    asyncio.create_task(watch_install(interaction.user, vps_id))


async def watch_install(user, vps_id):
    """Wait for a VPS to finish installing, then DM the owner the details."""
    deadline = time.time() + 25 * 60
    while time.time() < deadline:
        await asyncio.sleep(10)
        try:
            vps = vps_by_id(vps_id)
        except Exception:
            continue
        if not vps:
            return
        if (vps.get('status') or '').lower() == 'installing':
            continue
        ok = (vps.get('status') or '').lower() in ('running', 'stopped')
        if ok:
            _, pw = await api('GET', f'/vps/{vps_id}/password', timeout=30)
            e = vps_embed(vps, f"✅ VPS ready: {vps['container_name']}")
            e.color = COLOR_OK
            e.add_field(name='Root password', value=f"||{pw.get('password', 'see panel')}||", inline=False)
        else:
            e = embed('❌ VPS installation failed', f"{vps['container_name']} (#{vps_id}) - status: {vps.get('status')}. "
                      'Contact an admin or check the panel.', COLOR_ERR)
        try:
            await user.send(embed=e)
        except Exception as ex:
            log.warning('Could not DM %s: %s', user, ex)
        return


# ----------------------------------------------------------------------------
# Commands - everyone
# ----------------------------------------------------------------------------
@tree.command(name='help', description='Show what this bot can do')
async def cmd_help(interaction: discord.Interaction):
    admin = is_bot_admin(interaction.user.id)
    lines = [
        '**Members**',
        '`/register` - create your panel account',
        '`/deploy` - deploy a new VPS',
        '`/myvps` - list your VPS',
        '`/vpsinfo` `/start` `/stop` `/restart` `/password` - manage a VPS',
        '`/ostemplates` - list available operating systems',
    ]
    if admin:
        lines += [
            '', '**Admins**',
            '`/allvps` `/nodes` `/stats` - overview',
            '`/deploy_for` - deploy a VPS for any panel user',
            '`/delete` `/suspend` `/unsuspend` - control any VPS',
            '`/link` - link a Discord member to a panel account',
        ]
    if is_main_admin(interaction.user.id):
        lines += ['', '**Main admin**', '`/addadmin` `/removeadmin` `/botadmins` `/setname`']
    await reply(interaction, embed=embed(f'{client.user.name} - help', '\n'.join(lines)))


@tree.command(name='ping', description='Check that the bot is alive')
async def cmd_ping(interaction: discord.Interaction):
    await reply(interaction, content=f'🏓 Pong! {round(client.latency * 1000)} ms')


@tree.command(name='ostemplates', description='List the operating systems you can deploy')
async def cmd_os(interaction: discord.Interaction):
    items = await os_templates()
    await reply(interaction, embed=embed('Available operating systems',
                                         '\n'.join(f'• **{n}**  `{v}`' for n, v in items)))


@tree.command(name='register', description='Create a panel account linked to your Discord')
@app_commands.checks.cooldown(1, 30)
async def cmd_register(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)
    if panel_user_by_discord(interaction.user.id):
        return await reply(interaction, embed=embed('Already registered', 'Your Discord is already linked to a panel account.', COLOR_WARN))
    if get_setting('registration_enabled', '1') != '1' and not is_bot_admin(interaction.user.id):
        return await reply(interaction, embed=embed('Registration closed', 'Ask an admin for an account.', COLOR_ERR))

    base = re.sub(r'[^a-z0-9_]', '', interaction.user.name.lower())[:20] or 'user'
    username = base
    while panel_user_by_name(username):
        username = f'{base}{random.randint(100, 9999)}'
    password = ''.join(secrets.choice(string.ascii_letters + string.digits) for _ in range(14))

    status, data = await api('POST', '/users', {
        'username': username, 'email': f'{interaction.user.id}@discord.local',
        'password': password, 'is_admin': False})
    if status not in (200, 201) or not data.get('success'):
        return await reply(interaction, embed=embed('Registration failed', err_text(data), COLOR_ERR))
    try:
        with db() as conn:
            conn.execute('UPDATE users SET discord_id = ?, discord_username = ? WHERE id = ?',
                         (str(interaction.user.id), interaction.user.name, data['user_id']))
            conn.commit()
    except Exception as e:
        log.warning('link after register failed: %s', e)
    await reply(interaction, embed=embed('✅ Account created',
                                         f'**Username:** `{username}`\n**Password:** ||{password}||\n\n'
                                         'You can now use `/deploy` here, or log in to the web panel with these details. '
                                         'Change your password after your first login.', COLOR_OK))


@tree.command(name='myvps', description='List your VPS')
async def cmd_myvps(interaction: discord.Interaction):
    user = require_panel_user(interaction.user.id)
    if not user:
        return await reply(interaction, embed=embed('Not linked', NOT_LINKED, COLOR_WARN))
    rows = vps_for_user(user['id'])
    if not rows:
        return await reply(interaction, embed=embed('No VPS yet', 'Use `/deploy` to create one.'))
    text = '\n'.join(f"{status_icon(r)} **{r['container_name']}** (#{r['id']}) - {r.get('ram')} / {r.get('cpu')} CPU / {r.get('storage')}"
                     for r in rows[:25])
    await reply(interaction, embed=embed(f'Your VPS ({len(rows)})', text))


@tree.command(name='vpsinfo', description='Show details of a VPS')
@app_commands.describe(vps='Pick your VPS')
@app_commands.autocomplete(vps=vps_autocomplete)
async def cmd_vpsinfo(interaction: discord.Interaction, vps: int):
    row = vps_by_id(vps)
    if not row or not can_manage(interaction.user.id, row):
        return await reply(interaction, embed=embed('Not found', 'That VPS does not exist or is not yours.', COLOR_ERR))
    await reply(interaction, embed=vps_embed(row))


@tree.command(name='password', description='Get the root password of your VPS (only shown to you)')
@app_commands.describe(vps='Pick your VPS')
@app_commands.autocomplete(vps=vps_autocomplete)
async def cmd_password(interaction: discord.Interaction, vps: int):
    row = vps_by_id(vps)
    if not row or not can_manage(interaction.user.id, row):
        return await reply(interaction, embed=embed('Not found', 'That VPS does not exist or is not yours.', COLOR_ERR))
    await interaction.response.defer(ephemeral=True)
    status, data = await api('GET', f'/vps/{vps}/password', timeout=30)
    if status != 200 or not data.get('success'):
        return await reply(interaction, embed=embed('Failed', err_text(data), COLOR_ERR))
    await reply(interaction, embed=embed(f"🔑 {row['container_name']}", f"Root password: ||{data.get('password')}||", COLOR_OK))


@tree.command(name='deploy', description='Deploy a new VPS for yourself')
@app_commands.describe(name='Name for the VPS', os='Operating system', ram='RAM in GB',
                       cpu='CPU cores', storage='Disk in GB')
@app_commands.autocomplete(os=os_autocomplete)
@app_commands.checks.cooldown(1, 20)
async def cmd_deploy(interaction: discord.Interaction, name: str, os: str = 'ubuntu:22.04',
                     ram: int = 1, cpu: int = 1, storage: int = 10):
    admin = is_bot_admin(interaction.user.id)
    if get_setting('bot_allow_user_deploy', '1') != '1' and not admin:
        return await reply(interaction, embed=embed('Disabled', 'Deploying from the bot is turned off by the admin.', COLOR_ERR))
    user = require_panel_user(interaction.user.id)
    if not user:
        return await reply(interaction, embed=embed('Not linked', NOT_LINKED, COLOR_WARN))
    await interaction.response.defer(ephemeral=True)
    await start_deploy(interaction, user, name, os, ram, cpu, storage, limited=not admin)


async def power_action(interaction, vps_id, action, label):
    row = vps_by_id(vps_id)
    if not row or not can_manage(interaction.user.id, row):
        return await reply(interaction, embed=embed('Not found', 'That VPS does not exist or is not yours.', COLOR_ERR))
    if row.get('suspended') and not is_bot_admin(interaction.user.id):
        return await reply(interaction, embed=embed('Suspended', 'This VPS is suspended. Contact an admin.', COLOR_ERR))
    if (row.get('status') or '').lower() == 'installing':
        return await reply(interaction, embed=embed('Please wait', 'This VPS is still installing.', COLOR_WARN))
    await interaction.response.defer(ephemeral=True)
    status, data = await api('POST', f'/vps/{vps_id}/{action}')
    if status == 200 and data.get('success'):
        await reply(interaction, embed=embed(f"✅ {label}: {row['container_name']}", data.get('message', 'Done.'), COLOR_OK))
    else:
        await reply(interaction, embed=embed(f'{label} failed', err_text(data), COLOR_ERR))


@tree.command(name='start', description='Start a VPS')
@app_commands.describe(vps='Pick your VPS')
@app_commands.autocomplete(vps=vps_autocomplete)
async def cmd_start(interaction: discord.Interaction, vps: int):
    await power_action(interaction, vps, 'start', 'Started')


@tree.command(name='stop', description='Stop a VPS')
@app_commands.describe(vps='Pick your VPS')
@app_commands.autocomplete(vps=vps_autocomplete)
async def cmd_stop(interaction: discord.Interaction, vps: int):
    await power_action(interaction, vps, 'stop', 'Stopped')


@tree.command(name='restart', description='Restart a VPS')
@app_commands.describe(vps='Pick your VPS')
@app_commands.autocomplete(vps=vps_autocomplete)
async def cmd_restart(interaction: discord.Interaction, vps: int):
    await power_action(interaction, vps, 'restart', 'Restarted')


# ----------------------------------------------------------------------------
# Commands - bot admins
# ----------------------------------------------------------------------------
@tree.command(name='allvps', description='[Admin] List every VPS')
@bot_admin_only()
async def cmd_allvps(interaction: discord.Interaction):
    rows = query('SELECT v.*, u.username AS owner_name FROM vps v LEFT JOIN users u ON v.user_id = u.id ORDER BY v.id DESC LIMIT 30')
    if not rows:
        return await reply(interaction, embed=embed('No VPS', 'Nothing deployed yet.'))
    total = query_one('SELECT COUNT(*) AS c FROM vps')['c']
    text = '\n'.join(f"{status_icon(r)} **{r['container_name']}** (#{r['id']}) - {r.get('owner_name')} - {r.get('ram')}/{r.get('cpu')}CPU/{r.get('storage')}"
                     for r in rows)
    await reply(interaction, embed=embed(f'All VPS ({total}) - latest 30', text))


@tree.command(name='deploy_for', description='[Admin] Deploy a VPS for any panel user')
@app_commands.describe(username='Panel username of the owner', name='Name for the VPS', os='Operating system',
                       ram='RAM in GB', cpu='CPU cores', storage='Disk in GB', node='Node id (optional)')
@app_commands.autocomplete(os=os_autocomplete)
@bot_admin_only()
async def cmd_deploy_for(interaction: discord.Interaction, username: str, name: str, os: str = 'ubuntu:22.04',
                         ram: int = 1, cpu: int = 1, storage: int = 10, node: int = 0):
    owner = panel_user_by_name(username)
    if not owner:
        return await reply(interaction, embed=embed('User not found', f'No panel user called `{username}`.', COLOR_ERR))
    await interaction.response.defer(ephemeral=True)
    await start_deploy(interaction, owner, name, os, ram, cpu, storage, node_id=node or None, limited=False)


@tree.command(name='delete', description='[Admin] Delete a VPS permanently')
@app_commands.describe(vps='Pick the VPS', confirm='Type YES to confirm')
@app_commands.autocomplete(vps=vps_autocomplete)
@bot_admin_only()
async def cmd_delete(interaction: discord.Interaction, vps: int, confirm: str):
    row = vps_by_id(vps)
    if not row:
        return await reply(interaction, embed=embed('Not found', 'No such VPS.', COLOR_ERR))
    if confirm.strip().upper() != 'YES':
        return await reply(interaction, embed=embed('Not deleted', 'Type `YES` in the confirm field to delete.', COLOR_WARN))
    await interaction.response.defer(ephemeral=True)
    status, data = await api('DELETE', f'/vps/{vps}')
    if status == 200 and data.get('success'):
        await reply(interaction, embed=embed('🗑️ Deleted', f"{row['container_name']} (#{vps}) was deleted.", COLOR_OK))
    else:
        await reply(interaction, embed=embed('Delete failed', err_text(data), COLOR_ERR))


@tree.command(name='suspend', description='[Admin] Suspend a VPS')
@app_commands.describe(vps='Pick the VPS', reason='Reason (optional)')
@app_commands.autocomplete(vps=vps_autocomplete)
@bot_admin_only()
async def cmd_suspend(interaction: discord.Interaction, vps: int, reason: str = 'Suspended by admin via Discord bot'):
    await interaction.response.defer(ephemeral=True)
    status, data = await api('POST', f'/vps/{vps}/suspend', {'reason': reason})
    ok = status == 200 and data.get('success')
    await reply(interaction, embed=embed('⛔ Suspended' if ok else 'Failed', data.get('message', '') if ok else err_text(data),
                                         COLOR_OK if ok else COLOR_ERR))


@tree.command(name='unsuspend', description='[Admin] Unsuspend a VPS')
@app_commands.describe(vps='Pick the VPS')
@app_commands.autocomplete(vps=vps_autocomplete)
@bot_admin_only()
async def cmd_unsuspend(interaction: discord.Interaction, vps: int):
    await interaction.response.defer(ephemeral=True)
    status, data = await api('POST', f'/vps/{vps}/unsuspend')
    ok = status == 200 and data.get('success')
    await reply(interaction, embed=embed('✅ Unsuspended' if ok else 'Failed', data.get('message', '') if ok else err_text(data),
                                         COLOR_OK if ok else COLOR_ERR))


@tree.command(name='nodes', description='[Admin] Show nodes and their usage')
@bot_admin_only()
async def cmd_nodes(interaction: discord.Interaction):
    nodes = query('SELECT * FROM nodes')
    if not nodes:
        return await reply(interaction, embed=embed('No nodes', 'Add a node in the panel first.', COLOR_WARN))
    text = '\n'.join(f"**#{n['id']} {n.get('name')}** - {n.get('used_vps', 0)}/{n.get('total_vps', '?')} VPS" for n in nodes)
    await reply(interaction, embed=embed('Nodes', text))


@tree.command(name='stats', description='[Admin] Panel overview')
@bot_admin_only()
async def cmd_stats(interaction: discord.Interaction):
    users = query_one('SELECT COUNT(*) AS c FROM users')['c']
    by_status = query('SELECT status, COUNT(*) AS c FROM vps GROUP BY status')
    total = sum(r['c'] for r in by_status)
    lines = [f'**Users:** {users}', f'**VPS:** {total}'] + [f"• {r['status']}: {r['c']}" for r in by_status]
    await reply(interaction, embed=embed('📊 Panel stats', '\n'.join(lines)))


@tree.command(name='link', description='[Admin] Link a Discord member to a panel account')
@app_commands.describe(member='Discord member', username='Panel username')
@bot_admin_only()
async def cmd_link(interaction: discord.Interaction, member: discord.User, username: str):
    target = panel_user_by_name(username)
    if not target:
        return await reply(interaction, embed=embed('User not found', f'No panel user `{username}`.', COLOR_ERR))
    try:
        with db() as conn:
            conn.execute('UPDATE users SET discord_id = ?, discord_username = ? WHERE id = ?',
                         (str(member.id), member.name, target['id']))
            conn.commit()
    except sqlite3.IntegrityError:
        return await reply(interaction, embed=embed('Already linked', 'That Discord account is linked to another panel user.', COLOR_ERR))
    await reply(interaction, embed=embed('🔗 Linked', f'{member.mention} is now linked to **{target["username"]}**.', COLOR_OK))


# ----------------------------------------------------------------------------
# Commands - main admin
# ----------------------------------------------------------------------------
@tree.command(name='addadmin', description='[Main admin] Give someone bot admin rights')
@app_commands.describe(member='Discord member')
@main_admin_only()
async def cmd_addadmin(interaction: discord.Interaction, member: discord.User):
    ids = extra_admin_ids()
    ids.add(str(member.id))
    set_setting('bot_extra_admins', ','.join(sorted(ids)))
    await reply(interaction, embed=embed('✅ Admin added', f'{member.mention} is now a bot admin.', COLOR_OK))


@tree.command(name='removeadmin', description='[Main admin] Remove bot admin rights')
@app_commands.describe(member='Discord member')
@main_admin_only()
async def cmd_removeadmin(interaction: discord.Interaction, member: discord.User):
    ids = extra_admin_ids()
    ids.discard(str(member.id))
    set_setting('bot_extra_admins', ','.join(sorted(ids)))
    await reply(interaction, embed=embed('✅ Admin removed', f'{member.mention} is no longer a bot admin.', COLOR_OK))


@tree.command(name='botadmins', description='[Main admin] List bot admins')
@main_admin_only()
async def cmd_botadmins(interaction: discord.Interaction):
    lines = [f'👑 <@{main_admin_id()}> (main admin)'] + [f'🛡️ <@{i}>' for i in sorted(extra_admin_ids())]
    await reply(interaction, embed=embed('Bot admins', '\n'.join(lines)))


@tree.command(name='setname', description='[Main admin] Change the bot name')
@app_commands.describe(name='New bot name')
@main_admin_only()
async def cmd_setname(interaction: discord.Interaction, name: str):
    name = name.strip()
    if not 2 <= len(name) <= 32:
        return await reply(interaction, embed=embed('Invalid name', 'Use 2-32 characters.', COLOR_ERR))
    await interaction.response.defer(ephemeral=True)
    try:
        await client.user.edit(username=name)
        set_setting('bot_name', name)
        await reply(interaction, embed=embed('✅ Name changed', f'The bot is now called **{name}**.', COLOR_OK))
    except discord.HTTPException as e:
        await reply(interaction, embed=embed('Could not change name',
                                             f'Discord refused: {e.text or e}. (Discord only allows a couple of name changes per hour.)',
                                             COLOR_ERR))


# ----------------------------------------------------------------------------
# Events
# ----------------------------------------------------------------------------
@tree.error
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.CheckFailure) and not isinstance(error, app_commands.CommandOnCooldown):
        msg = str(error) or 'You cannot use this command.'
        e = embed('🚫 No permission', msg, COLOR_ERR)
    elif isinstance(error, app_commands.CommandOnCooldown):
        e = embed('⏳ Slow down', f'Try again in {error.retry_after:.0f}s.', COLOR_WARN)
    else:
        log.exception('Command error: %s', error)
        e = embed('Something went wrong', 'The command failed. Please try again or tell an admin.', COLOR_ERR)
    try:
        await reply(interaction, embed=e)
    except Exception:
        pass


@client.event
async def on_ready():
    log.info('Logged in as %s (%s)', client.user, client.user.id)
    wanted = (get_setting('bot_name', '') or '').strip()
    if wanted and wanted != client.user.name:
        try:
            await client.user.edit(username=wanted)
            log.info('Bot name changed to %s', wanted)
        except discord.HTTPException as e:
            log.warning('Could not change bot name (Discord rate limit?): %s', e)
    try:
        synced = await tree.sync()
        log.info('Synced %d slash commands', len(synced))
    except Exception as e:
        log.error('Slash command sync failed: %s', e)
    await client.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name='your VPS | /help'))
    if not main_admin_id():
        log.warning('No main admin Discord ID is set - admin commands are disabled until you set one in the panel.')


def main():
    token = (get_setting('bot_token', '') or '').strip()
    if not token:
        log.error('No Discord bot token set. Add it in the panel: Admin -> Discord Bot.')
        sys.exit(1)
    try:
        client.run(token)
    except discord.LoginFailure:
        log.error('Discord rejected the token. Check it in Admin -> Discord Bot.')
        sys.exit(1)


if __name__ == '__main__':
    main()
